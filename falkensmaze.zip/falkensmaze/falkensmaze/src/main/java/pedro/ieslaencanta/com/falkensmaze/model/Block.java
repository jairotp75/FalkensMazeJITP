/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pedro.ieslaencanta.com.falkensmaze.model;

import jakarta.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;
/** 
 * La clase Block implementa Serializable junto con un constructor por defecto que 
 * inicializa el bloque con valor a null. Se devuelve y se establece el valor al bloque 
 * comprobando si ese bloque está vacio.
 * 
 */ 

@XmlRootElement
public class Block implements  Serializable {
    private String value;
    
    public Block(){
        this.value=null;
    }
    public String getValue(){
        return this.value;
    }
    public void setValue(String value){
        this.value=value;
    }
    public boolean isEmpty(){
        return this.value==null;
    }
}
